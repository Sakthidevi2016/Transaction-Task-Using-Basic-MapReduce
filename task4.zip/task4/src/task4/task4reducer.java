package task4;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class task4reducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable>{
    public void reduce(Text inpk, Iterable<DoubleWritable> inpv, Context c) throws IOException, InterruptedException{
   	   double count=0;
   	   for(DoubleWritable x: inpv)
   	 {
   		   count = count + x.get();
   	   }
   		   c.write(inpk, new DoubleWritable(count));
      }
  }
