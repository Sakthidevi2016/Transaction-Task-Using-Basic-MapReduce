package task3;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class task3reducer extends Reducer<Text, DoubleWritable, Text, Text>{
    public void reduce(Text inpk, Iterable<DoubleWritable> inpv, Context c) throws IOException, InterruptedException{
  	   int count=0;
  	   double sum=0;
  	   double avg;
  	 for(DoubleWritable x: inpv)
  	 {
  		   count++;
  		   sum = sum + x.get();
  	   }
  		   avg = sum/count;
  	   c.write(inpk, new Text(sum+" "+count+" "+avg));
     }
 }
